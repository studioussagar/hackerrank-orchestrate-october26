import pandas as pd
import json

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Find all deletion_worker events targeting account_service
dw = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()
dw['dt'] = pd.to_datetime(dw['event_time'])

status_map = {
    'SUCCESS': 'COMPLETE',
    'FAILED': 'NOT_STARTED',
    'PARTIAL': 'PARTIALLY_COMPLETE'
}

matches = []
for _, r in sample_req.iterrows():
    cid = r['case_id']
    rep_at = pd.to_datetime(r['reported_at'])
    rep_stat = r['reported_status']
    
    # find dw events before or near reported_at with matching status
    dw['diff'] = (dw['dt'] - rep_at).abs()
    # Let's filter to events within 2 hours
    cand = dw[dw['diff'] <= pd.Timedelta(hours=2)].copy()
    cand['mapped_stat'] = cand['reported_result'].map(status_map)
    matching_cand = cand[cand['mapped_stat'] == rep_stat]
    
    # Get expected account from sample_output
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    expected_steps = json.loads(out_row['steps_json'])
    expected_accounts = [s['resource_id'] for s in expected_steps if s['system_id'] == 'account_service']
    
    print(f"{cid}: rep_stat={rep_stat}, expected={expected_accounts}")
    for _, c in matching_cand.iterrows():
        print(f"   cand: {c['resource_id']} at {c['event_time']} diff={c['diff']}")
