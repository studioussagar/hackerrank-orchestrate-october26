import os, glob, json, re
import pandas as pd
from pathlib import Path

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
ef = pd.read_csv('dataset/evidence_files.csv')

# Build user identity map
user_map = {}
for _, u in users.iterrows():
    uid = u['user_id']
    user_map[uid] = {
        'user_id': uid,
        'emails': {u['email'].lower()},
        'phones': {str(u['phone'])},
        'hashes': {str(u['email_hash'])}
    }

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid not in user_map:
        user_map[uid] = {'user_id': uid, 'emails': set(), 'phones': set(), 'hashes': set()}
    f = a['field_name']
    if f == 'email':
        if pd.notna(a['old_value']): user_map[uid]['emails'].add(a['old_value'].lower())
        if pd.notna(a['new_value']): user_map[uid]['emails'].add(a['new_value'].lower())
    elif f == 'phone':
        if pd.notna(a['old_value']): user_map[uid]['phones'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_map[uid]['phones'].add(str(a['new_value']))
    elif f == 'email_hash':
        if pd.notna(a['old_value']): user_map[uid]['hashes'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_map[uid]['hashes'].add(str(a['new_value']))

email_to_uid = {}
for uid, d in user_map.items():
    for em in d['emails']:
        email_to_uid[em] = uid

for _, req in sample_req.iterrows():
    cid = req['case_id']
    req_email = req['email'].lower()
    uid = email_to_uid.get(req_email)
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    expected_steps = json.loads(out_row['steps_json'])
    
    # print summary
    print(f"=== {cid} ({uid}) ===")
    for s in expected_steps:
        rid = s['resource_id']
        sys_id = s['system_id']
        op = s['operation']
        eid = s.get('evidence_id')
        print(f"  {s['phase']:12} | {sys_id:20} | {rid:18} | {op:25} | {eid}")
