import os, glob, sqlite3, json
from pathlib import Path
import pandas as pd

user_to_account = {}

# 1. Check all SQL files
sql_files = glob.glob('dataset/evidence/databases/*.sql')
for sf in sql_files:
    conn = sqlite3.connect(':memory:')
    with open(sf, 'r', encoding='utf-8') as f:
        content = f.read()
    try:
        conn.executescript(content)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [r[0] for r in cursor.fetchall()]
        for t in tables:
            cursor.execute(f"PRAGMA table_info({t});")
            cols = [c[1] for c in cursor.fetchall()]
            if 'resource_id' in cols and 'user_id' in cols and 'account' in t:
                cursor.execute(f"SELECT user_id, resource_id FROM {t}")
                for u, r in cursor.fetchall():
                    if u not in user_to_account:
                        user_to_account[u] = set()
                    user_to_account[u].add(r)
            elif 'resource_id' in cols and 'record_payload' in cols:
                cursor.execute(f"SELECT resource_id, record_payload FROM {t}")
                for r, payload in cursor.fetchall():
                    try:
                        pdata = json.loads(payload)
                        u = pdata.get('customer_reference') or pdata.get('user_id')
                        if u and 'account' in r:
                            if u not in user_to_account: user_to_account[u] = set()
                            user_to_account[u].add(r)
                    except: pass
    except Exception as e:
        pass
    finally:
        conn.close()

# 2. Check JSON bundles
for jp in glob.glob('dataset/evidence/records/*.json'):
    with open(jp, 'r', encoding='utf-8') as f:
        try:
            data = json.load(f)
            # check snapshots
            if 'snapshots' in data:
                for s in data['snapshots']:
                    for rec in s.get('records', []):
                        rid = rec.get('resource_id')
                        uid = rec.get('customer_reference') or rec.get('user_id')
                        if rid and uid and 'account' in rid:
                            user_to_account.setdefault(uid, set()).add(rid)
        except: pass

print(f"Total user_ids with account resource found in evidence files: {len(user_to_account)}")
for u in ['user_01', 'user_02', 'user_03', 'user_04', 'user_05', 'user_11', 'user_26', 'user_541', 'user_542']:
    print(f"  {u}: {user_to_account.get(u)}")
