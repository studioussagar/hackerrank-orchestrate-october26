import os, glob, json
import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
ef = pd.read_csv('dataset/evidence_files.csv')

# Build user identity map
user_map = {}
for _, u in users.iterrows():
    uid = u['user_id']
    user_map[uid] = {
        'user_id': uid,
        'emails': {u['email'].lower()},
        'phones': {str(u['phone'])},
        'hashes': {str(u['email_hash'])}
    }

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid not in user_map:
        user_map[uid] = {'user_id': uid, 'emails': set(), 'phones': set(), 'hashes': set()}
    f = a['field_name']
    if f == 'email':
        if pd.notna(a['old_value']): user_map[uid]['emails'].add(a['old_value'].lower())
        if pd.notna(a['new_value']): user_map[uid]['emails'].add(a['new_value'].lower())
    elif f == 'phone':
        if pd.notna(a['old_value']): user_map[uid]['phones'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_map[uid]['phones'].add(str(a['new_value']))
    elif f == 'email_hash':
        if pd.notna(a['old_value']): user_map[uid]['hashes'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_map[uid]['hashes'].add(str(a['new_value']))

email_to_uid = {}
for uid, d in user_map.items():
    for em in d['emails']:
        email_to_uid[em] = uid

# Load all text/json/sql/log files
evidence_contents = {}
for _, row in ef.iterrows():
    fid = row['file_id']
    fpath = os.path.join('dataset', row['file_path'])
    if os.path.exists(fpath) and not fpath.endswith(('.png', '.pdf')):
        with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
            evidence_contents[fid] = (row['file_path'], row['captured_at'], f.read())

print(f"Loaded {len(evidence_contents)} evidence files into memory.")

for _, req in sample_req.iterrows():
    cid = req['case_id']
    req_email = req['email'].lower()
    uid = email_to_uid.get(req_email)
    aud_at = req['audit_at']
    
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    expected_steps = json.loads(out_row['steps_json'])
    expected_res = set(s['resource_id'] for s in expected_steps)
    
    idents = user_map.get(uid, {})
    all_idents = [uid] + list(idents.get('emails', [])) + list(idents.get('phones', [])) + list(idents.get('hashes', []))
    
    # Find all evidence files captured at or before aud_at that mention any of all_idents
    matching_evidence = []
    for fid, (fpath, cap_at, content) in evidence_contents.items():
        if cap_at <= aud_at:
            for ident in all_idents:
                if ident in content:
                    matching_evidence.append((fid, fpath, cap_at, ident))
                    break
    
    expected_eids = set(s.get('evidence_id') for s in expected_steps if s.get('evidence_id'))
    found_eids = set(m[0] for m in matching_evidence)
    
    print(f"{cid} ({uid}): expected evidence {expected_eids}, found matching files {found_eids}")
    if not expected_eids.issubset(found_eids):
        print(f"  MISSING EVIDENCES: {expected_eids - found_eids}")
