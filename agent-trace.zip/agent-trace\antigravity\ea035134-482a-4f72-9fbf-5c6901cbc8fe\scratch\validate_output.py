import json
import os
import pandas as pd

OUTPUT_FILE = "output.csv"
INPUT_FILE = "dataset/deletion_requests.csv"

def validate():
    print(f"=== Validating {OUTPUT_FILE} ===")
    assert os.path.exists(OUTPUT_FILE), f"{OUTPUT_FILE} does not exist!"
    
    df = pd.read_csv(OUTPUT_FILE)
    print(f"Total rows: {len(df)}")
    assert len(df) == 518, f"Expected 518 rows, got {len(df)}"
    
    expected_cols = ["case_id", "deletion_status", "steps_json"]
    assert list(df.columns) == expected_cols, f"Columns mismatch: {list(df.columns)} vs {expected_cols}"
    
    # Check input alignment
    in_df = pd.read_csv(INPUT_FILE)
    expected_case_ids = in_df["case_id"].tolist()
    
    actual_case_ids = df["case_id"].tolist()
    assert set(actual_case_ids) == set(expected_case_ids), "Case IDs set does not match input!"
    
    # Check sorting
    def case_sort_key(cid: str):
        parts = cid.split("_")
        return int(parts[1]) if len(parts) == 2 and parts[1].isdigit() else cid
    
    sorted_case_ids = sorted(actual_case_ids, key=case_sort_key)
    assert actual_case_ids == sorted_case_ids, "output.csv is not correctly sorted by case_id!"
    
    allowed_statuses = {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
    allowed_phases = {"FINDING", "REMEDIATION", "VERIFICATION"}
    
    allowed_ops = {
        "REPORT_REMAINING_RECORD", "REPORT_EXPOSED_PII", "REPORT_ACTIVE_DATA_FLOW", "REPORT_RESTORE_RISK",
        "DISABLE_DATA_FLOW", "BLOCK_RESTORE", "DELETE_RECORD", "REDACT_RECORD", "ANONYMIZE_RECORD",
        "VERIFY_RECORD_ABSENT", "VERIFY_RECORD_PRESENT", "VERIFY_RECORD_REDACTED", "VERIFY_RECORD_ANONYMIZED",
        "VERIFY_DATA_FLOW_DISABLED", "VERIFY_RESTORE_BLOCKED"
    }
    
    allowed_states = {"PRESENT", "ABSENT", "ACTIVE", "DISABLED", "BLOCKED", "REDACTED", "ANONYMIZED"}
    
    for idx, row in df.iterrows():
        cid = row["case_id"]
        status = row["deletion_status"]
        assert status in allowed_statuses, f"Row {idx} ({cid}): invalid status {status}"
        
        raw_steps = row["steps_json"]
        try:
            steps = json.loads(raw_steps)
        except Exception as e:
            assert False, f"Row {idx} ({cid}): invalid JSON: {e}"
            
        assert isinstance(steps, list), f"Row {idx} ({cid}): steps_json is not a list"
        
        if status == "NOT_APPLICABLE":
            assert len(steps) == 0, f"Row {idx} ({cid}): NOT_APPLICABLE must have empty steps_json, got {steps}"
        else:
            # Check steps
            for s_idx, s in enumerate(steps, 1):
                assert isinstance(s, dict), f"Row {idx} ({cid}) step {s_idx}: not a dict"
                expected_keys = {"step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"}
                assert set(s.keys()) == expected_keys, f"Row {idx} ({cid}) step {s_idx}: invalid keys {set(s.keys())}"
                assert s["step_no"] == s_idx, f"Row {idx} ({cid}) step {s_idx}: step_no is {s['step_no']}, expected {s_idx}"
                assert s["phase"] in allowed_phases, f"Row {idx} ({cid}) step {s_idx}: invalid phase {s['phase']}"
                assert s["operation"] in allowed_ops, f"Row {idx} ({cid}) step {s_idx}: invalid op {s['operation']}"
                assert s["state"] in allowed_states, f"Row {idx} ({cid}) step {s_idx}: invalid state {s['state']}"
                
                # Check evidence_id rules
                if status == "INCOMPLETE":
                    if s["phase"] == "FINDING":
                        assert s["evidence_id"] != "", f"Row {idx} ({cid}) finding step must have evidence_id!"
                    else:
                        assert s["evidence_id"] == "", f"Row {idx} ({cid}) remediation/post-verification must have empty evidence_id!"
                elif status == "COMPLETE":
                    assert s["phase"] == "VERIFICATION", f"Row {idx} ({cid}) COMPLETE case can only have VERIFICATION steps!"
                    assert s["evidence_id"] != "", f"Row {idx} ({cid}) COMPLETE case verification must cite evidence_id!"

    print("ALL VALIDATION CHECKS PASSED PERFECTLY!")

if __name__ == "__main__":
    validate()
