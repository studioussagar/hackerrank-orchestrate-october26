import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for item in data['service_exports']['security_service']['audit_records']:
    if item.get('subject_reference') == 'user_28':
        print("user_28 audit_record:", item)
