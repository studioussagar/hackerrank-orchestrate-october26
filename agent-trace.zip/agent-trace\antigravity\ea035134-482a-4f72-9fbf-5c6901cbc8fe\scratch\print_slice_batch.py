import pandas as pd

activity = pd.read_csv('dataset/system_activity.csv')
print(activity.loc[3527:3542, ['activity_id', 'event_time', 'event_type', 'source_system', 'target_system', 'resource_id', 'reported_result', 'details']].to_string())
