import pandas as pd, json, os, glob
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Build mapping of email -> user_id, and user_id -> all emails/phones/hashes/names
user_identifiers = {}
for _, u in users.iterrows():
    uid = u['user_id']
    user_identifiers[uid] = {
        'user_id': uid,
        'names': {u['name'].lower()},
        'emails': {u['email'].lower()},
        'phones': {str(u['phone'])},
        'hashes': {str(u['email_hash'])}
    }

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid not in user_identifiers:
        user_identifiers[uid] = {'user_id': uid, 'names': set(), 'emails': set(), 'phones': set(), 'hashes': set()}
    field = a['field_name']
    if field == 'email':
        if pd.notna(a['old_value']): user_identifiers[uid]['emails'].add(a['old_value'].lower())
        if pd.notna(a['new_value']): user_identifiers[uid]['emails'].add(a['new_value'].lower())
    elif field == 'phone':
        if pd.notna(a['old_value']): user_identifiers[uid]['phones'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_identifiers[uid]['phones'].add(str(a['new_value']))
    elif field == 'email_hash':
        if pd.notna(a['old_value']): user_identifiers[uid]['hashes'].add(str(a['old_value']))
        if pd.notna(a['new_value']): user_identifiers[uid]['hashes'].add(str(a['new_value']))

# Reverse map from email -> uid
email_to_uid = {}
for uid, d in user_identifiers.items():
    for em in d['emails']:
        email_to_uid[em] = uid

for _, req in sample_req.iterrows():
    cid = req['case_id']
    email = req['email'].lower()
    uid = email_to_uid.get(email)
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    expected_resources = set(s['resource_id'] for s in steps)
    
    # Check where each expected resource is mentioned
    idents = user_identifiers.get(uid, {})
    all_ident_strings = [uid] + list(idents.get('emails', [])) + list(idents.get('phones', [])) + list(idents.get('hashes', []))
    
    print(f"=== {cid} ({uid}) ===")
    for rid in sorted(expected_resources):
        # Check system_activity.csv
        act_rows = activity[activity['resource_id'] == rid]
        act_matches = []
        for _, ar in act_rows.iterrows():
            det = str(ar['details']).lower()
            matching_ids = [ident for ident in all_ident_strings if ident and ident.lower() in det]
            act_matches.append((ar['activity_id'], ar['event_time'], ar['event_type'], matching_ids))
        
        print(f"  {rid}:")
        if act_matches:
            print(f"    in activity: {act_matches}")
        else:
            print(f"    NOT in activity (or no resource_id match)")
