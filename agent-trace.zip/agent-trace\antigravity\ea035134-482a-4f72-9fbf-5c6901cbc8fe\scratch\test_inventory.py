import os, glob, json, re, sqlite3
import pandas as pd

# Load evidence manifest
ef_df = pd.read_csv('dataset/evidence_files.csv')
print(f"Loaded {len(ef_df)} evidence files.")

# Test parsing each category of evidence
# 1. service_resource_export_*.json
exports = ef_df[ef_df['origin'] == 'service_resource_export']
print(f"service_resource_export count: {len(exports)}")

# 2. records_assurance_snapshot_bundle_*.json
bundles = ef_df[ef_df['origin'] == 'records_assurance_snapshot_bundle']
print(f"records_assurance_snapshot_bundle count: {len(bundles)}")

# 3. service_readback_logs (*.log)
readbacks = ef_df[ef_df['origin'] == 'service_readback_logs']
print(f"service_readback_logs count: {len(readbacks)}")

# 4. central_observability_export (*.log)
observ = ef_df[ef_df['origin'] == 'central_observability_export']
print(f"central_observability_export count: {len(observ)}")

# 5. SQL snapshots
sqls = ef_df[ef_df['file_path'].str.endswith('.sql')]
print(f"SQL snapshots count: {len(sqls)}")

# 6. Text handovers
txts = ef_df[ef_df['file_path'].str.endswith('.txt')]
print(f"Text records count: {len(txts)}")

# 7. PDFs
pdfs = ef_df[ef_df['file_path'].str.endswith('.pdf')]
print(f"PDFs count: {len(pdfs)}")
