import pandas as pd
from datetime import datetime

activity = pd.read_csv('dataset/system_activity.csv')
del_act = activity[activity['source_system'] == 'deletion_worker'].copy()
del_act['dt'] = pd.to_datetime(del_act['event_time'])

print(f"Total deletion_worker events: {len(del_act)}")
print(del_act['event_type'].value_counts())
print(del_act['target_system'].value_counts())
