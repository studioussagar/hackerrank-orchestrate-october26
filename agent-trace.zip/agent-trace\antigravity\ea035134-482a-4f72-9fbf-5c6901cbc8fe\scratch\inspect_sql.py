import os, sqlite3, glob
from pathlib import Path

sql_files = glob.glob('dataset/evidence/databases/*.sql')
print(f'Total SQL files: {len(sql_files)}')
for sf in sorted(sql_files):
    fname = Path(sf).name
    conn = sqlite3.connect(':memory:')
    with open(sf, 'r', encoding='utf-8') as f:
        content = f.read()
    try:
        conn.executescript(content)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [r[0] for r in cursor.fetchall()]
        table_counts = {}
        for t in tables:
            cursor.execute(f'SELECT count(*) FROM {t}')
            table_counts[t] = cursor.fetchone()[0]
        print(f'{fname}: {table_counts}')
    except Exception as e:
        print(f'{fname}: ERROR {e}')
    finally:
        conn.close()
