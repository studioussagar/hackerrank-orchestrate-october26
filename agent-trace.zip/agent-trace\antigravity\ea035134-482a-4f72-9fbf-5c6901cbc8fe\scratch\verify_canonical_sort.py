import json
import pandas as pd

sample_out = pd.read_csv('dataset/sample_output.csv')

op_phase = {
    'REPORT_REMAINING_RECORD': 'FINDING',
    'REPORT_EXPOSED_PII': 'FINDING',
    'REPORT_ACTIVE_DATA_FLOW': 'FINDING',
    'REPORT_RESTORE_RISK': 'FINDING',
    
    'DISABLE_DATA_FLOW': 'REMEDIATION',
    'BLOCK_RESTORE': 'REMEDIATION',
    'DELETE_RECORD': 'REMEDIATION',
    'REDACT_RECORD': 'REMEDIATION',
    'ANONYMIZE_RECORD': 'REMEDIATION',
    
    'VERIFY_RECORD_ABSENT': 'VERIFICATION',
    'VERIFY_RECORD_PRESENT': 'VERIFICATION',
    'VERIFY_RECORD_REDACTED': 'VERIFICATION',
    'VERIFY_RECORD_ANONYMIZED': 'VERIFICATION',
    'VERIFY_DATA_FLOW_DISABLED': 'VERIFICATION',
    'VERIFY_RESTORE_BLOCKED': 'VERIFICATION'
}

finding_order = [
    'REPORT_REMAINING_RECORD',
    'REPORT_EXPOSED_PII',
    'REPORT_ACTIVE_DATA_FLOW',
    'REPORT_RESTORE_RISK'
]

remediation_order = [
    'DISABLE_DATA_FLOW',
    'BLOCK_RESTORE',
    'DELETE_RECORD',
    'REDACT_RECORD',
    'ANONYMIZE_RECORD'
]

verification_order = [
    'VERIFY_RECORD_ABSENT',
    'VERIFY_RECORD_PRESENT',
    'VERIFY_RECORD_REDACTED',
    'VERIFY_RECORD_ANONYMIZED',
    'VERIFY_DATA_FLOW_DISABLED',
    'VERIFY_RESTORE_BLOCKED'
]

# Check every row in sample_output.csv to see how steps are sorted!
mismatches = 0
for _, r in sample_out.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    # Check phases
    phases = [s['phase'] for s in steps]
    expected_phases = sorted(phases, key=lambda p: ['FINDING', 'REMEDIATION', 'VERIFICATION'].index(p))
    if phases != expected_phases:
        print(f"{cid} phase mismatch: {phases} vs {expected_phases}")
        mismatches += 1
        
    # Check operations within each phase
    findings = [s for s in steps if s['phase'] == 'FINDING']
    remed = [s for s in steps if s['phase'] == 'REMEDIATION']
    verif = [s for s in steps if s['phase'] == 'VERIFICATION']
    
    sorted_findings = sorted(findings, key=lambda s: (finding_order.index(s['operation']), s['system_id'], s['resource_id']))
    sorted_remed = sorted(remed, key=lambda s: (remediation_order.index(s['operation']), s['system_id'], s['resource_id']))
    sorted_verif = sorted(verif, key=lambda s: (verification_order.index(s['operation']), s['system_id'], s['resource_id']))
    
    if findings != sorted_findings:
        print(f"{cid} finding order mismatch:\n  actual: {[f['operation'] for f in findings]}\n  expect: {[f['operation'] for f in sorted_findings]}")
        mismatches += 1
    if remed != sorted_remed:
        print(f"{cid} remed order mismatch:\n  actual: {[f['operation'] for f in remed]}\n  expect: {[f['operation'] for f in sorted_remed]}")
        mismatches += 1
    if verif != sorted_verif:
        print(f"{cid} verif order mismatch:\n  actual: {[f['operation'] for f in verif]}\n  expect: {[f['operation'] for f in sorted_verif]}")
        mismatches += 1

print(f"Total order mismatches: {mismatches}")
