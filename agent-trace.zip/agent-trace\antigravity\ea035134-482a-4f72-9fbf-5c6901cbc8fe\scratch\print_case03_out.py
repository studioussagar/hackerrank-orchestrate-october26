import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
r3 = sample_out[sample_out['case_id'] == 'case_03'].iloc[0]
print("case_03 status:", r3['deletion_status'])
for s in json.loads(r3['steps_json']):
    print(" ", s)
