import pandas as pd

activity = pd.read_csv('dataset/system_activity.csv')
for _, r in activity.iterrows():
    line = " ".join(str(x) for x in r.values)
    if any(k in line for k in ['user_27', 'account_3866', 'analytics_4574', 'support_4707', 'data_flow_2295', 'backup_5970', 'audit_record_3830']):
        print(f"{r['activity_id']} {r['event_time']} {r['event_type']} {r['source_system']} -> {r['target_system']} {r['resource_id']} | {r['details']}")
