import json
import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

incomplete_cases = []
for _, r in sample_out.iterrows():
    cid = r['case_id']
    if r['deletion_status'] == 'INCOMPLETE':
        steps = json.loads(r['steps_json'])
        findings = [s for s in steps if s['phase'] == 'FINDING']
        req = sample_req[sample_req['case_id'] == cid].iloc[0]
        incomplete_cases.append({
            'case_id': cid,
            'email': req['email'],
            'reported_status': req['reported_status'],
            'findings': [(f['system_id'], f['resource_id'], f['operation'], f['evidence_id']) for f in findings]
        })

print(f"Total incomplete sample cases: {len(incomplete_cases)}")
for c in incomplete_cases:
    print(f"=== {c['case_id']} ({c['reported_status']}) ===")
    for f in c['findings']:
        print(f"  {f}")
