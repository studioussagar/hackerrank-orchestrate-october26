import json

with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for s in data['snapshots']:
    col = s.get('collection')
    for rec in s.get('records', []):
        rec_str = str(rec)
        if '4857' in rec_str or '8858' in rec_str or 'user_541' in rec_str or 'user_542' in rec_str:
            print(f"Collection: {col} -> {rec}")
