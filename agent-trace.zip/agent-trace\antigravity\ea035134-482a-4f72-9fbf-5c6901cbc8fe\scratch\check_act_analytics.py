import pandas as pd

activity = pd.read_csv('dataset/system_activity.csv')
print(activity[activity['resource_id'] == 'analytics_4574'])
