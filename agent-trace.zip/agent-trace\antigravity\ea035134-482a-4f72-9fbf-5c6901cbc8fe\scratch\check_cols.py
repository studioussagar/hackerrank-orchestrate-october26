import pandas as pd

activity = pd.read_csv('dataset/system_activity.csv')
print(activity.columns.tolist())
