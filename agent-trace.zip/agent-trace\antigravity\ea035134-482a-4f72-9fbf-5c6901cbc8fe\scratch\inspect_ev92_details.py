import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("Keys in service_resource_export:", list(data.keys()))
for svc, content in data.items():
    print(f"Service: {svc}, type: {type(content)}")
    if isinstance(content, dict):
        print(f"  subkeys: {list(content.keys())}")
        for sk, items in content.items():
            if isinstance(items, list):
                print(f"    {sk}: count={len(items)}")
                # check if user_27 or account_3866 or analytics_4574 is in here
                for item in items:
                    item_str = str(item)
                    if 'account_3866' in item_str or 'user_27' in item_str or 'analytics_4574' in item_str:
                        print(f"      FOUND in {svc}->{sk}: {item}")
