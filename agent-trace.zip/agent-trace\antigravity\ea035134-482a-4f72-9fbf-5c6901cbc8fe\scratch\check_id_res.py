import os, glob, json, re
import pandas as pd

# Load all identities and audit logs
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
eval_req = pd.read_csv('dataset/deletion_requests.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
all_req = pd.concat([sample_req, eval_req], ignore_index=True)

# Build email -> user_id mapping
email_to_uid = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

# For each user, collect all their identifiers:
uid_to_idents = {}
for _, u in users.iterrows():
    uid = u['user_id']
    idents = {uid.lower(), str(u['email']).lower(), str(u['phone']).lower(), str(u['email_hash']).lower(), str(u['name']).lower()}
    uid_to_idents[uid] = idents

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid in uid_to_idents:
        if pd.notna(a['old_value']): uid_to_idents[uid].add(str(a['old_value']).lower())
        if pd.notna(a['new_value']): uid_to_idents[uid].add(str(a['new_value']).lower())

print(f"Total users: {len(uid_to_idents)}")

# Now let's check how many requests resolve to a user_id
unresolved = 0
for _, r in all_req.iterrows():
    e = str(r['email']).lower()
    if e not in email_to_uid:
        unresolved += 1
print(f"Unresolved requests: {unresolved} / {len(all_req)}")
