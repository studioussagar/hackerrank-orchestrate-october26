with open('dataset/evidence/records/customer_account_handover_20261001.txt', 'r', encoding='utf-8') as f:
    for line in f:
        if 'user_32' in line or 'novak.tomasz' in line or 'account_4248' in line:
            print(line.strip())
