import os

for root, dirs, files in os.walk('dataset'):
    for file in files:
        if file.endswith(('csv', 'txt', 'log', 'json', 'sql', 'md')):
            path = os.path.join(root, file)
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    for lno, line in enumerate(f, 1):
                        if 'account_5482' in line:
                            print(f"{path}:{lno} -> {line.strip()[:150]}")
            except: pass
