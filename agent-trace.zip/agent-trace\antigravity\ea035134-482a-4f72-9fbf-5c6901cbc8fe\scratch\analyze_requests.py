import sys
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd

df = pd.read_csv('dataset/deletion_requests.csv')
print(f"Total deletion requests: {len(df)}")

# Let's inspect unique patterns or classify request texts
# Common intents: DELETION, ACCESS/EXPORT, CORRECTION/RECTIFICATION, MARKETING_OPTOUT, OTHER

access_words = ['access', 'export', 'download', 'copy', 'portability', 'acceso', 'accès', 'zugang', 'accesso', 'télécharger', 'descargar']
rectify_words = ['correct', 'rectify', 'update my details', 'rectificación', 'korrektur', 'rettifica']
optout_words = ['unsubscribe', 'opt out', 'opt-out', 'marketing', 'newsletter', 'desuscribir', 'désabonner']
delete_words = ['delete', 'deletion', 'erase', 'erasure', 'erased', 'remove', 'close', 'eliminar', 'suppression', '削除', 'supprimer', 'borrar', 'cancella', 'löschen', 'exclusão', 'excluir', 'supprimé', 'eliminado', 'gelöscht']

results = []
for i, r in df.iterrows():
    text = r['request_text']
    text_lower = text.lower()
    
    is_delete = any(w in text_lower for w in delete_words)
    is_access = any(w in text_lower for w in ['only download', 'only export', 'request access', 'subject access', 'access request', 'send me a copy'])
    is_optout = any(w in text_lower for w in ['opt out of marketing', 'stop marketing', 'unsubscribe from emails'])
    
    results.append({
        'case_id': r['case_id'],
        'email': r['email'],
        'text': text,
        'is_delete': is_delete
    })

non_del = [r for r in results if not r['is_delete']]
print(f"Number of texts without standard delete words: {len(non_del)}")
for r in non_del:
    print(f"{r['case_id']}: {r['text']}")
