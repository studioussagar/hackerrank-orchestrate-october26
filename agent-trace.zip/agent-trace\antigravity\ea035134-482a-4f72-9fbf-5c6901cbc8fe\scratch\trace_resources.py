import os, glob, json
from pathlib import Path
import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

# Load all dataset files into memory or searchable text
files = {}
for p in glob.glob('dataset/**', recursive=True):
    if os.path.isfile(p):
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                files[p] = f.read()
        except:
            pass

for _, req in sample_req.head(10).iterrows():
    cid = req['case_id']
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    print(f"=== {cid} ({req['email']}) ===")
    for s in steps:
        rid = s['resource_id']
        found_in = []
        for path, content in files.items():
            if 'sample_output' in path: continue
            if rid in content:
                found_in.append(Path(path).name)
        print(f"  {rid} ({s['system_id']}, {s['operation']}) found in: {found_in}")
