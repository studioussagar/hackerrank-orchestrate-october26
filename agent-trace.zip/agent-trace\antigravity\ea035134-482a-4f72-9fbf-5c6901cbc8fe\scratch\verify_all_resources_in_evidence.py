import os, glob, json
import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')

# Build mapping from email -> user_id, and user_id -> all identifiers
email_to_uid = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

uid_to_idents = {}
for _, u in users.iterrows():
    uid = u['user_id']
    uid_to_idents[uid] = {uid, u['email'].lower(), str(u['phone']), str(u['email_hash'])}

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid not in uid_to_idents: uid_to_idents[uid] = {uid}
    if pd.notna(a['old_value']): uid_to_idents[uid].add(str(a['old_value']).lower())
    if pd.notna(a['new_value']): uid_to_idents[uid].add(str(a['new_value']).lower())

# Load all evidence text files
ef = pd.read_csv('dataset/evidence_files.csv')
file_contents = {}
for _, r in ef.iterrows():
    fid = r['file_id']
    fp = os.path.join('dataset', r['file_path'])
    if os.path.exists(fp) and not fp.endswith('.png'):
        if fp.endswith('.pdf'):
            import pypdf
            reader = pypdf.PdfReader(fp)
            text = " ".join(p.extract_text() for p in reader.pages)
            file_contents[fid] = (r['file_path'], r['captured_at'], text)
        else:
            with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                file_contents[fid] = (r['file_path'], r['captured_at'], f.read())

print("Loaded all non-png evidence files.")

for _, req in sample_req.iterrows():
    cid = req['case_id']
    email = req['email'].lower()
    uid = email_to_uid[email]
    idents = uid_to_idents[uid]
    
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    
    print(f"=== {cid} ({uid}) ===")
    for s in steps:
        rid = s['resource_id']
        eid = s.get('evidence_id')
        found_in = []
        for f_id, (f_path, cap_at, content) in file_contents.items():
            if rid in content:
                # check if any ident in content too
                has_ident = any(i in content.lower() for i in idents)
                found_in.append((f_id, has_ident))
        print(f"  {rid} ({s['system_id']}): cited in sample={eid}, found in files={found_in}")
