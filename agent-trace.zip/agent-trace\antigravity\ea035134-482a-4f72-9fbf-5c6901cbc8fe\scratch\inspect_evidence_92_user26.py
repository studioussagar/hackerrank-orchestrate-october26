import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json') as f:
    data = json.load(f)

for sname, sdata in data['service_exports'].items():
    for subk, items in sdata.items():
        for item in items:
            if 'user_26' in str(item) or any(r in str(item) for r in ['account_5684', 'analytics_4566', 'support_4715', 'data_flow_6244', 'backup_3120', 'audit_record_5416']):
                print(sname, subk, item)
