import pandas as pd
import json
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

# Build email/user_id index
email_to_user = {}
for _, u in users.iterrows():
    email_to_user[u['email'].lower()] = u['user_id']
for _, a in audit.iterrows():
    if a['field_name'] == 'email':
        if pd.notna(a['old_value']):
            email_to_user[a['old_value'].lower()] = a['user_id']
        if pd.notna(a['new_value']):
            email_to_user[a['new_value'].lower()] = a['user_id']

for _, req in sample_req.iterrows():
    cid = req['case_id']
    email = req['email'].lower()
    uid = email_to_user.get(email, 'UNKNOWN')
    req_at = pd.to_datetime(req['requested_at'])
    rep_at = pd.to_datetime(req['reported_at'])
    aud_at = pd.to_datetime(req['audit_at'])
    
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    out_resources = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s.get('evidence_id')) for s in steps]
    
    # Let's find activities between requested_at and reported_at (+ 1 hour)
    window_act = activity[(activity['dt'] >= req_at - timedelta(hours=1)) & (activity['dt'] <= rep_at + timedelta(hours=1))]
    
    # Also find activities mentioning uid or email
    direct_act = activity[activity['details'].str.contains(uid, na=False) | activity['details'].str.contains(email, na=False)]
    
    print(f"=== {cid} | {req['email']} | {uid} | reported: {req['reported_status']} ===")
    print(f"  Window: {req_at} to {rep_at}")
    print(f"  Expected steps ({len(steps)}):")
    for s in out_resources:
        print(f"    {s}")
    
    # Check which expected resources are in window_act
    window_res = set(window_act['resource_id'])
    print(f"  Window activity resources ({len(window_res)}): {window_res}")
    
    print()
