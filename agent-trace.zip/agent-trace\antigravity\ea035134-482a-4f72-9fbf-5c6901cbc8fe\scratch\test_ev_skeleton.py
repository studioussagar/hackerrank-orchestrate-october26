import sys
sys.stdout.reconfigure(encoding='utf-8')
import os, glob, json, re, sqlite3
import pandas as pd
from datetime import datetime

# Load base files
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
rules = pd.read_csv('dataset/deletion_rules.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
ef_df = pd.read_csv('dataset/evidence_files.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Build mapping
email_to_uid = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

# Map each uid to all its identifiers
uid_to_idents = {}
for _, u in users.iterrows():
    uid = u['user_id']
    idents = {uid.lower(), str(u['email']).lower(), str(u['phone']).lower(), str(u['email_hash']).lower(), str(u['name']).lower()}
    uid_to_idents[uid] = idents

for _, a in audit.iterrows():
    uid = a['user_id']
    if uid in uid_to_idents:
        if pd.notna(a['old_value']): uid_to_idents[uid].add(str(a['old_value']).lower())
        if pd.notna(a['new_value']): uid_to_idents[uid].add(str(a['new_value']).lower())

print("Setup completed successfully.")
