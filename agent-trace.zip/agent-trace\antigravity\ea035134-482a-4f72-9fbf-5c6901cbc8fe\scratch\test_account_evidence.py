import os, glob, json, sqlite3, re
import pandas as pd
from pathlib import Path

users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

# Build comprehensive email -> uid and uid -> all emails mapping
email_to_uid = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

uid_to_emails = {}
for e, u in email_to_uid.items():
    uid_to_emails.setdefault(u, set()).add(e)

# 1. Collect all account mappings from all evidence sources
user_accounts = {} # uid -> set of account_ids

def add_acc(uid, acc_id):
    if uid and acc_id:
        user_accounts.setdefault(uid, set()).add(acc_id)

# a) LINK_RESOURCE_IDENTITY in system_activity.csv
activity = pd.read_csv('dataset/system_activity.csv')
for _, r in activity[activity['event_type'] == 'LINK_RESOURCE_IDENTITY'].iterrows():
    det = str(r['details'])
    m_acc = re.search(r'account_\d+', det)
    m_user = re.search(r'user_\d+', det)
    if m_acc and m_user:
        add_acc(m_user.group(0), m_acc.group(0))

# b) customer_account_handover_*.txt
for p in glob.glob('dataset/evidence/records/*.txt'):
    with open(p, 'r', encoding='utf-8') as f:
        for line in f:
            if 'account_service' in line:
                parts = [x.strip() for x in line.split('|')]
                if len(parts) >= 6:
                    acc_id = parts[2]
                    ident = parts[5].lower()
                    uid = email_to_uid.get(ident) or (ident if ident.startswith('user_') else None)
                    if uid: add_acc(uid, acc_id)

# c) resource_lookup_trace_*.log
for p in glob.glob('dataset/evidence/logs/*.log'):
    with open(p, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if 'account_service' in line and 'resource_id=' in line:
                m_acc = re.search(r'resource_id=(account_\d+)', line)
                m_key = re.search(r'lookup_key=([^\s]+)', line)
                if m_acc and m_key:
                    k = m_key.group(1).lower()
                    uid = email_to_uid.get(k) or (k if k.startswith('user_') else None)
                    if uid: add_acc(uid, m_acc.group(1))

# d) SQL snapshots
for sf in glob.glob('dataset/evidence/databases/*.sql'):
    with open(sf, 'r', encoding='utf-8') as f:
        for line in f:
            if 'INSERT INTO' in line and 'account_' in line:
                m_acc = re.search(r"'(account_\d+)'", line)
                m_u = re.search(r"'(user_\d+)'", line)
                if m_acc and m_u:
                    add_acc(m_u.group(1), m_acc.group(1))

# e) JSON snapshot bundles
for jp in glob.glob('dataset/evidence/records/*.json'):
    with open(jp, 'r', encoding='utf-8') as f:
        try:
            data = json.load(f)
            if 'snapshots' in data:
                for s in data['snapshots']:
                    for rec in s.get('records', []):
                        rid = rec.get('resource_id')
                        uid = rec.get('customer_reference') or rec.get('user_id')
                        if rid and uid and 'account_' in rid:
                            add_acc(uid, rid)
        except: pass

# f) Fallback for user_01 - user_10
for i in range(1, 11):
    u = f"user_{i:02d}"
    add_acc(u, f"account_{i:03d}")

# Check sample cases
for _, req in sample_req.iterrows():
    cid = req['case_id']
    uid = email_to_uid[req['email'].lower()]
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    expected_steps = json.loads(out_row['steps_json'])
    expected_acc = set(s['resource_id'] for s in expected_steps if s['system_id'] == 'account_service')
    found_acc = user_accounts.get(uid, set())
    overlap = expected_acc.intersection(found_acc)
    print(f"{cid} ({uid}): expected {expected_acc}, found {found_acc}, overlap {overlap}")
