import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for svc, content in data['service_exports'].items():
    print(f"\n--- Service: {svc} ---")
    if isinstance(content, dict):
        for sk, items in content.items():
            print(f"  {sk}: count={len(items) if isinstance(items, list) else type(items)}")
            if isinstance(items, list):
                for item in items:
                    item_str = str(item)
                    if any(x in item_str for x in ['account_3866', 'user_27', 'analytics_4574', 'audit_record_8048']):
                        print(f"    MATCH: {item}")
