import os, shutil, zipfile

SOURCE_DIR = r"C:\Users\sagar\.gemini\antigravity-ide\brain\ea035134-482a-4f72-9fbf-5c6901cbc8fe"
DEST_PARENT = os.path.abspath("agent-trace")
DEST_DIR = os.path.join(DEST_PARENT, "antigravity", "ea035134-482a-4f72-9fbf-5c6901cbc8fe")

print(f"Staging agent trace from {SOURCE_DIR} to {DEST_DIR}...")
if os.path.exists(DEST_PARENT):
    shutil.rmtree(DEST_PARENT)

os.makedirs(DEST_DIR, exist_ok=True)

# Copy contents
for root, dirs, files in os.walk(SOURCE_DIR):
    rel = os.path.relpath(root, SOURCE_DIR)
    target_subdir = os.path.join(DEST_DIR, rel) if rel != "." else DEST_DIR
    os.makedirs(target_subdir, exist_ok=True)
    for f in files:
        src_file = os.path.join(root, f)
        dst_file = os.path.join(target_subdir, f)
        shutil.copy2(src_file, dst_file)

# Also copy log.txt into agent-trace/ for completeness
if os.path.exists("log.txt"):
    shutil.copy2("log.txt", os.path.join(DEST_PARENT, "log.txt"))

print("Staging complete. Calculating size...")
total_size = 0
file_count = 0
for root, dirs, files in os.walk(DEST_PARENT):
    for f in files:
        total_size += os.path.getsize(os.path.join(root, f))
        file_count += 1

print(f"Staged {file_count} files ({total_size / (1024*1024):.2f} MB).")
