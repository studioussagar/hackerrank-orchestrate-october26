import pandas as pd
ef = pd.read_csv('dataset/evidence_files.csv')
print(ef.columns.tolist())
print(ef[ef['file_id'] == 'evidence_94'].to_dict(orient='records'))
