import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for item in data['service_exports']['account_service']['profile_lookups']:
    if item.get('resource_id') == 'account_5482':
        print("account_5482 lookup:", item)
