import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

# Look at case_03: user_43, email in sample_req
r3 = sample_req[sample_req['case_id'] == 'case_03'].iloc[0]
print("case_03:", r3['email'], r3['requested_at'], r3['reported_status'], r3['reported_at'])

# Look at all events between requested_at and reported_at + 1h
t_start = pd.to_datetime(r3['requested_at']) - pd.Timedelta(minutes=5)
t_end = pd.to_datetime(r3['reported_at']) + pd.Timedelta(minutes=5)

evs = activity[(activity['dt'] >= t_start) & (activity['dt'] <= t_end)]
print(f"Events between {t_start} and {t_end}: {len(evs)}")
for _, e in evs.iterrows():
    print(f"  {e['activity_id']} {e['event_time']} {e['event_type']} {e['source_system']} -> {e['target_system']} res={e['resource_id']} res_stat={e['reported_result']} det={e['details']}")
