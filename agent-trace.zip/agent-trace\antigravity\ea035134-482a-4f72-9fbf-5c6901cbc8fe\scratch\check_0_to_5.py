import sys
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
req_dict = sample_req.set_index('case_id').to_dict(orient='index')

rows = []
for _, r in sample_out.iloc[:6].iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    req = req_dict[cid]
    findings = [s for s in steps if s['phase'] == 'FINDING']
    remed = [s for s in steps if s['phase'] == 'REMEDIATION']
    verif = [s for s in steps if s['phase'] == 'VERIFICATION']
    finding_summary = "; ".join([f"{f['system_id']}:{f['resource_id']}:{f['operation']}" for f in findings])
    ev_ids = list(set([s['evidence_id'] for s in steps if s['evidence_id']]))
    rows.append({
        'case_id': cid,
        'rep_status': req['reported_status'],
        'true_status': status,
        'findings': finding_summary,
        'evidence': ",".join(ev_ids)
    })

print(pd.DataFrame(rows).to_string())
