import pandas as pd
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

for _, req in sample_req.head(5).iterrows():
    cid = req['case_id']
    req_at = pd.to_datetime(req['requested_at'])
    rep_at = pd.to_datetime(req['reported_at'])
    
    sub = activity[(activity['dt'] >= req_at) & (activity['dt'] <= rep_at + timedelta(minutes=10))]
    del_sub = sub[sub['source_system'].isin(['deletion_worker', 'account_service', 'integration_service'])]
    print(f"=== {cid} ({req['email']}, reported: {req['reported_at']}) ===")
    print(f"  Activity in window: {len(sub)} rows, deletion worker: {len(del_sub)} rows")
    for _, r in del_sub.iterrows():
        print(f"    {r['event_time']} | {r['event_type']} | {r['target_system']} | {r['resource_id']} | {r['reported_result']}")
