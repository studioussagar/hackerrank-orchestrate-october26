import pandas as pd
ef = pd.read_csv('dataset/evidence_files.csv')
r = ef[ef['file_id'] == 'evidence_94'].iloc[0]
print(r['file_id'], r['file_path'], r['source_origin'], r['captured_at'])
