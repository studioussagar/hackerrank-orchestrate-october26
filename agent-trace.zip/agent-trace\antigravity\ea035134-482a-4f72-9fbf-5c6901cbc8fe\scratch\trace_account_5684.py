import os, glob

for p in glob.glob('dataset/**', recursive=True):
    if os.path.isfile(p):
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                c = f.read()
                if 'account_5684' in c:
                    print('account_5684 in:', p)
                if 'analytics_4566' in c:
                    print('analytics_4566 in:', p)
        except:
            pass
