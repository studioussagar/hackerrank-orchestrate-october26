import sys
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
ef = pd.read_csv('dataset/evidence_files.csv').set_index('file_id')

req_dict = sample_req.set_index('case_id').to_dict(orient='index')

for _, row in sample_out.iterrows():
    cid = row['case_id']
    status = row['deletion_status']
    steps = json.loads(row['steps_json'])
    req = req_dict[cid]
    print(f"==================================================")
    print(f"CASE: {cid} | Status: {status} | RepStatus: {req['reported_status']} | AuditAt: {req['audit_at']}")
    for s in steps:
        ev_id = s['evidence_id']
        ev_info = ""
        if ev_id in ef.index:
            ev_row = ef.loc[ev_id]
            ev_info = f"[{ev_id}: {ev_row['origin']} {ev_row['file_path']} cap={ev_row['captured_at']}]"
        print(f"  Step {s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {ev_id} {ev_info}")
