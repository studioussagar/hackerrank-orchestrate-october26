import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for svc, content in data['service_exports'].items():
    if isinstance(content, dict):
        for sk, items in content.items():
            if isinstance(items, list):
                for item in items:
                    item_str = str(item)
                    if any(x in item_str for x in ['support_2351', 'data_flow_2337', 'backup_838', 'analytics_6077']):
                        print(f"{svc}->{sk}: {item}")
