import pandas as pd

ef_df = pd.read_csv('dataset/evidence_files.csv')
categorized = (
    ef_df['origin'].isin(['service_resource_export', 'records_assurance_snapshot_bundle', 'service_readback_logs', 'central_observability_export']) |
    ef_df['file_path'].str.endswith(('.sql', '.txt', '.pdf', '.png'))
)
other = ef_df[~categorized]
print(f"Other count: {len(other)}")
print(other[['file_id', 'origin', 'file_path', 'captured_at']])
