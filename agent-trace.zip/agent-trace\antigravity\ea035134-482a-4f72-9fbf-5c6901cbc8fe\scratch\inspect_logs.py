import os, glob
from pathlib import Path

log_files = glob.glob('dataset/evidence/logs/*.log')
print(f'Total log files: {len(log_files)}')
for lf in sorted(log_files):
    fname = Path(lf).name
    with open(lf, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [f.readline().strip() for _ in range(5)]
    print(f'=== {fname} ===')
    for l in lines:
        if l:
            print(f'  {l[:120]}')
