import os, glob, json
from pathlib import Path

audit_records = {} # uid -> list of (rid, filename, cap_at)

for p in glob.glob('dataset/evidence/records/*.json'):
    fname = Path(p).name
    with open(p, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # check service_resource_export
    if 'service_exports' in data and 'security_service' in data['service_exports']:
        for rec in data['service_exports']['security_service'].get('audit_records', []):
            sref = rec.get('subject_reference')
            rid = rec.get('resource_id')
            if sref and rid:
                audit_records.setdefault(sref, []).append((rid, fname))
    
    # check snapshots
    if 'snapshots' in data:
        for s in data['snapshots']:
            if s.get('collection') == 'security_audit_events' or 'security_audit' in str(s):
                for rec in s.get('records', []):
                    sref = rec.get('subject_reference')
                    rid = rec.get('resource_id')
                    if sref and rid:
                        audit_records.setdefault(sref, []).append((rid, fname))

    # check security_audit_ledger
    if 'security_audit_ledger' in fname:
        for rec in data.get('records', []):
            sref = rec.get('subject_reference') or rec.get('user_id')
            rid = rec.get('resource_id')
            if sref and rid:
                audit_records.setdefault(sref, []).append((rid, fname))

print(f"Total UIDs with audit records in JSON exports: {len(audit_records)}")
for u in ['user_21', 'user_26', 'user_27', 'user_28', 'user_29', 'user_30', 'user_541', 'user_542']:
    print(f"  {u}: {audit_records.get(u)}")
