import os, sys, json, glob, sqlite3
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])
ef = pd.read_csv('dataset/evidence_files.csv')

# Build identity maps
email_to_uid = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

# Map uid to all identifiers
uid_to_idents = {}
for _, u in users.iterrows():
    uid = u['user_id']
    uid_to_idents[uid] = {
        'uid': uid,
        'emails': {u['email'].lower()},
        'phones': {str(u['phone'])},
        'hashes': {str(u['email_hash'])}
    }
for _, a in audit.iterrows():
    uid = a['user_id']
    if uid not in uid_to_idents: uid_to_idents[uid] = {'uid': uid, 'emails': set(), 'phones': set(), 'hashes': set()}
    f = a['field_name']
    if f == 'email':
        if pd.notna(a['old_value']): uid_to_idents[uid]['emails'].add(a['old_value'].lower())
        if pd.notna(a['new_value']): uid_to_idents[uid]['emails'].add(a['new_value'].lower())
    elif f == 'phone':
        if pd.notna(a['old_value']): uid_to_idents[uid]['phones'].add(str(a['old_value']))
        if pd.notna(a['new_value']): uid_to_idents[uid]['phones'].add(str(a['new_value']))
    elif f == 'email_hash':
        if pd.notna(a['old_value']): uid_to_idents[uid]['hashes'].add(str(a['old_value']))
        if pd.notna(a['new_value']): uid_to_idents[uid]['hashes'].add(str(a['new_value']))

print("Ready to test full linkage on sample cases.")
