import os, glob, json
import pandas as pd

ef = pd.read_csv('dataset/evidence_files.csv')
print(f"Total evidence files: {len(ef)}")
print(ef['origin'].value_counts())

for origin, group in ef.groupby('origin'):
    sample_file = group.iloc[0]
    print(f"\n--- Origin: {origin} (Count: {len(group)}) ---")
    print(f"Sample: {sample_file['file_id']} -> {sample_file['file_path']}")
