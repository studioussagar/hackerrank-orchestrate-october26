import os, sys, json, glob, sqlite3, re
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd
import pypdf

ef = pd.read_csv('dataset/evidence_files.csv')
file_to_eid = dict(zip(ef['file_path'], ef['file_id']))
eid_to_cap = dict(zip(ef['file_id'], ef['captured_at']))

print("Testing full parser...")
