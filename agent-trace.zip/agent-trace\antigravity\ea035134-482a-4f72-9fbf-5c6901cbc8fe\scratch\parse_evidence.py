import os, json, glob, sqlite3, pypdf
import pandas as pd
from pathlib import Path

ef = pd.read_csv('dataset/evidence_files.csv')
print(f"Total evidence files in manifest: {len(ef)}")

# Let's inspect how observations can be extracted from each evidence file
