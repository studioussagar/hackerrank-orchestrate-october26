import pandas as pd

ef_df = pd.read_csv('dataset/evidence_files.csv')
fids = ['evidence_08', 'evidence_13', 'evidence_36', 'evidence_41', 'evidence_50', 'evidence_56', 'evidence_59', 'evidence_61']
sub = ef_df[ef_df['file_id'].isin(fids)]
for _, r in sub.iterrows():
    print(f"{r['file_id']}: origin={r['origin']} path={r['file_path']} cap={r['captured_at']}")
