import pandas as pd
import json
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')

e_to_u = dict(zip(users['email'].str.lower(), users['user_id']))
for _, a in audit[audit['field_name']=='email'].iterrows():
    if pd.notna(a['old_value']): e_to_u[a['old_value'].lower()] = a['user_id']
    if pd.notna(a['new_value']): e_to_u[a['new_value'].lower()] = a['user_id']

for _, req in sample_req.iterrows():
    cid = req['case_id']
    uid = e_to_u[req['email'].lower()]
    rep_at = pd.to_datetime(req['reported_at'])
    req_at = pd.to_datetime(req['requested_at'])
    aud_at = pd.to_datetime(req['audit_at'])
    
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    expected_steps = json.loads(out_row['steps_json'])
    expected_res = set(s['resource_id'] for s in expected_steps)
    
    # Check deletion_worker activities around reported_at
    # Let's see: within [reported_at - 1h, reported_at + 3h]
    sub_act = activity[(activity['dt'] >= rep_at - timedelta(hours=2)) & (activity['dt'] <= rep_at + timedelta(hours=3))]
    
    # Check overlap of resource_id
    res_in_sub = set(sub_act['resource_id'])
    overlap = expected_res.intersection(res_in_sub)
    missing = expected_res - res_in_sub
    
    print(f"{cid} ({uid}, {req['reported_status']}): expected {len(expected_res)}, found in window {len(overlap)}, missing {missing}")
