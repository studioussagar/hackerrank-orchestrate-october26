import os, glob
from pathlib import Path

target = 'account_010'
print(f'Searching for {target}...')

for p in glob.glob('dataset/**', recursive=True):
    if os.path.isfile(p):
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                if target in content:
                    print(f'Found in: {p} (count: {content.count(target)})')
        except Exception:
            pass
