import pandas as pd
import json
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

for _, req in sample_req.iterrows():
    cid = req['case_id']
    rep_at = pd.to_datetime(req['reported_at'])
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    
    # Expected account resource
    expected_acc = [s['resource_id'] for s in steps if s['system_id'] == 'account_service']
    
    # Find account activities around reported_at
    acc_act = activity[(activity['target_system'] == 'account_service') & (activity['event_type'] == 'DELETE_RECORD') & 
                       (activity['dt'] >= rep_at - timedelta(hours=2)) & (activity['dt'] <= rep_at + timedelta(hours=3))]
    
    print(f"{cid} (rep: {req['reported_at']}): expected acc={expected_acc}, act_acc={list(acc_act['resource_id'])}")
