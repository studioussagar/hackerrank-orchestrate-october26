import sys
sys.stdout.reconfigure(encoding='utf-8')
import json
import pandas as pd

pred_df = pd.read_csv('sample_run_output.csv')
true_df = pd.read_csv('dataset/sample_output.csv')

total_cases = len(true_df)
status_matches = 0
step_matches = 0

print(f"=== Comparing sample predictions ({len(pred_df)}) with ground truth ({len(true_df)}) ===")

for idx, true_row in true_df.iterrows():
    cid = true_row['case_id']
    pred_row = pred_df[pred_df['case_id'] == cid].iloc[0]
    
    true_status = true_row['deletion_status']
    pred_status = pred_row['deletion_status']
    
    stat_ok = (true_status == pred_status)
    if stat_ok:
        status_matches += 1
        
    true_steps = json.loads(true_row['steps_json'])
    pred_steps = json.loads(pred_row['steps_json'])
    
    # Compare steps
    # We compare: phase, system_id, resource_id, operation, state
    t_sig = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in true_steps]
    p_sig = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in pred_steps]
    
    step_ok = (t_sig == p_sig)
    if step_ok:
        step_matches += 1
    else:
        print(f"\n--- {cid} (Status: Pred={pred_status}, True={true_status}) ---")
        print(f"True steps ({len(true_steps)}):")
        for s in true_steps:
            print(f"  {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")
        print(f"Pred steps ({len(pred_steps)}):")
        for s in pred_steps:
            print(f"  {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")

print(f"\n=== SUMMARY ===")
print(f"Status Accuracy: {status_matches} / {total_cases} ({status_matches/total_cases*100:.1f}%)")
print(f"Exact Step Sequence Accuracy: {step_matches} / {total_cases} ({step_matches/total_cases*100:.1f}%)")
