import sys
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd

df = pd.read_csv('dataset/deletion_requests.csv')

# Explicit phrases that negate deletion or request non-deletion actions
non_delete_phrases = [
    'not asking for deletion',
    'not a request to erase',
    'leave the account active',
    'keep the account as it is',
    'do not close the account',
    'without removing any of my records',
    'marketing lists only',
    'leave my profile and purchase history in place',
    'continue using the service',
    "don't delete or change anything",
    'do not delete'
]

found = []
for i, r in df.iterrows():
    t = r['request_text'].lower()
    for p in non_delete_phrases:
        if p in t:
            found.append((r['case_id'], r['request_text']))
            break

print(f"Total found non-deletion requests: {len(found)}")
for cid, text in found:
    print(f"  {cid}: {text}")
