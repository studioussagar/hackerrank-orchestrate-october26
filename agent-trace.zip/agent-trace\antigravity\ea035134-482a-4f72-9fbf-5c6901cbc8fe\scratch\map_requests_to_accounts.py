import pandas as pd
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
eval_req = pd.read_csv('dataset/deletion_requests.csv')
all_req = pd.concat([sample_req, eval_req], ignore_index=True)

activity = pd.read_csv('dataset/system_activity.csv')
del_acc = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()
del_acc['dt'] = pd.to_datetime(del_acc['event_time'])

all_req['rep_dt'] = pd.to_datetime(all_req['reported_at'])

# Sort both by reported_at / event_time
all_req = all_req.sort_values('rep_dt').reset_index(drop=True)
del_acc = del_acc.sort_values('dt').reset_index(drop=True)

print(f"Total requests: {len(all_req)}")
print(f"Total account delete events: {len(del_acc)}")

# Let's see how close each request's reported_at is to an account delete event
matched = 0
for _, req in all_req.iterrows():
    if req['reported_status'] == 'NOT_STARTED': continue
    rep_at = req['rep_dt']
    # find closest event
    diffs = (del_acc['dt'] - rep_at).abs()
    min_diff = diffs.min()
    if min_diff <= timedelta(hours=3):
        matched += 1

print(f"Requests with reported_status != NOT_STARTED: {len(all_req[all_req['reported_status'] != 'NOT_STARTED'])}")
print(f"Matched with account delete event within 3h: {matched}")
