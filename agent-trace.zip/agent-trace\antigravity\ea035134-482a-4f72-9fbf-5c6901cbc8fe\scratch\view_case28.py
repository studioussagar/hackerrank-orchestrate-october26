import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
print(sample_req[sample_req['case_id'] == 'case_28'].to_dict(orient='records'))
