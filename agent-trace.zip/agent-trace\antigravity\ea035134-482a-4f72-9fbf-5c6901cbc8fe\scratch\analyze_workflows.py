import pandas as pd
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
eval_req = pd.read_csv('dataset/deletion_requests.csv')
all_req = pd.concat([sample_req, eval_req], ignore_index=True)

activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')

# Build email -> uid mapping
email_to_uid = {}
for _, u in users.iterrows():
    email_to_uid[u['email'].lower()] = u['user_id']
for _, a in audit.iterrows():
    if a['field_name'] == 'email':
        if pd.notna(a['old_value']): email_to_uid[a['old_value'].lower()] = a['user_id']
        if pd.notna(a['new_value']): email_to_uid[a['new_value'].lower()] = a['user_id']

print("Total requests:", len(all_req))
print("Matched UIDs for requests:", sum(1 for _, r in all_req.iterrows() if r['email'].lower() in email_to_uid))

# Check any un-matched emails
unmatched = [r['email'] for _, r in all_req.iterrows() if r['email'].lower() not in email_to_uid]
print("Unmatched request emails count:", len(unmatched))
if unmatched:
    print("Sample unmatched:", unmatched[:5])
