import json
import pandas as pd

sample_out = pd.read_csv('dataset/sample_output.csv')

for _, r in sample_out.iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    
    phases = [s['phase'] for s in steps]
    ops = [s['operation'] for s in steps]
    
    # Check phase ordering: FINDING -> REMEDIATION -> VERIFICATION
    phase_order = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}
    p_nums = [phase_order[p] for p in phases]
    assert p_nums == sorted(p_nums), f"{cid}: phases not sorted: {phases}"
    
    # Check step_no consecutive starting from 1
    step_nos = [s['step_no'] for s in steps]
    assert step_nos == list(range(1, len(steps) + 1)), f"{cid}: step_nos not consecutive: {step_nos}"
    
    if status == 'COMPLETE':
        assert all(p == 'VERIFICATION' for p in phases), f"{cid}: COMPLETE has non-verification phases: {phases}"
        assert all(s['evidence_id'] != '' for s in steps), f"{cid}: COMPLETE has empty evidence_id: {steps}"
    elif status == 'INCOMPLETE':
        findings = [s for s in steps if s['phase'] == 'FINDING']
        rems = [s for s in steps if s['phase'] == 'REMEDIATION']
        vers = [s for s in steps if s['phase'] == 'VERIFICATION']
        assert len(findings) > 0, f"{cid}: INCOMPLETE has no findings"
        assert len(rems) > 0, f"{cid}: INCOMPLETE has no remediations"
        assert len(vers) > 0, f"{cid}: INCOMPLETE has no verifications"
        assert all(s['evidence_id'] != '' for s in findings), f"{cid}: finding has empty evidence_id"
        assert all(s['evidence_id'] == '' for s in rems), f"{cid}: remediation has non-empty evidence_id"
        assert all(s['evidence_id'] == '' for s in vers), f"{cid}: verification has non-empty evidence_id"

print("All sample_output.csv structure checks PASSED!")
