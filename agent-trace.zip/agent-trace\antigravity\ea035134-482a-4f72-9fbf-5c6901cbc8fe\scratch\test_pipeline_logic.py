import os, glob, json
import pandas as pd
from datetime import datetime

# Load all public sample data
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')
audit = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])
ef = pd.read_csv('dataset/evidence_files.csv')

print(f"Testing pipeline logic against {len(sample_req)} sample cases.")
