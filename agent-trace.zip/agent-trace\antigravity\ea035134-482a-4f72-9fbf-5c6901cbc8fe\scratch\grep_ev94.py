with open('dataset/evidence/logs/resource_lookup_trace_20260926_103856.log', 'r', encoding='utf-8') as f:
    for line in f:
        if 'account_7566' in line or 'analytics_9406' in line or 'audit_record_2016' in line:
            print(line.strip())
