import pandas as pd

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')

cids = ['case_09', 'case_12', 'case_15', 'case_16', 'case_17', 'case_18', 'case_19']
sub_req = sample_req[sample_req['case_id'].isin(cids)]
print("--- REQUESTS ---")
print(sub_req[['case_id', 'email', 'requested_at', 'reported_status', 'reported_at', 'audit_at']])

del_workers = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()
print("\n--- DELETION WORKER ACCOUNT EVENTS NEAR THESE TIMESTAMPS ---")
for _, r in sub_req.iterrows():
    rep_at = pd.to_datetime(r['reported_at'])
    del_workers['diff'] = (pd.to_datetime(del_workers['event_time']) - rep_at).abs()
    near = del_workers.sort_values('diff').head(3)
    print(f"\nRequest {r['case_id']} (reported_at={r['reported_at']}, status={r['reported_status']}):")
    for _, dw in near.iterrows():
        print(f"  activity: {dw['activity_id']} {dw['event_time']} res={dw['resource_id']} result={dw['reported_result']} diff={dw['diff']} details={dw['details'][:80]}")
