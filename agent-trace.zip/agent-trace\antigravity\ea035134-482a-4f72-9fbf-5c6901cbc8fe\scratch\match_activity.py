import pandas as pd
import json
from datetime import datetime, timedelta

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')

activity['dt'] = pd.to_datetime(activity['event_time'])

for _, req in sample_req.head(10).iterrows():
    cid = req['case_id']
    rep_at = pd.to_datetime(req['reported_at'])
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    out_resources = set(s['resource_id'] for s in steps)
    
    act_near = activity[(activity['dt'] >= rep_at - timedelta(minutes=5)) & (activity['dt'] <= rep_at + timedelta(minutes=5))]
    act_res = set(act_near['resource_id'])
    
    overlap = out_resources.intersection(act_res)
    print(f"{cid} (reported: {req['reported_at']}, status: {req['reported_status']}):")
    print(f"  out_resources: {out_resources}")
    print(f"  activity near reported_at: {act_res}")
    print(f"  overlap: {overlap}")
    print()
