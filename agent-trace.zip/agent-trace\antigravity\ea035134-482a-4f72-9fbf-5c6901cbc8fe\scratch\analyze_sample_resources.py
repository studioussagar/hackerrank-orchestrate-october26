import pandas as pd, json

sample_out = pd.read_csv('dataset/sample_output.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
ef = pd.read_csv('dataset/evidence_files.csv')
ef_map = dict(zip(ef['file_id'], ef['file_path']))

for _, r in sample_out.iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    req_row = sample_req[sample_req['case_id'] == cid].iloc[0]
    
    systems = [s['system_id'] for s in steps]
    operations = [s['operation'] for s in steps]
    evidence_ids = [s.get('evidence_id') for s in steps if s.get('evidence_id')]
    
    print(f"{cid} ({status}): req_reported={req_row['reported_status']}")
    print(f"  systems: {list(dict.fromkeys(systems))}")
    print(f"  operations: {list(dict.fromkeys(operations))}")
    print(f"  evidence cited: {list(dict.fromkeys(evidence_ids))}")
    for eid in set(evidence_ids):
        print(f"    {eid} -> {ef_map.get(eid)}")
