import pandas as pd

eval_req = pd.read_csv('dataset/deletion_requests.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
all_req = pd.concat([sample_req, eval_req], ignore_index=True)

activity = pd.read_csv('dataset/system_activity.csv')
dw_acc = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()
dw_acc['dt'] = pd.to_datetime(dw_acc['event_time'])
dw_acc = dw_acc.sort_values('dt').reset_index(drop=True)

print(f"Total requests: {len(all_req)}")
print(f"Total dw_acc events: {len(dw_acc)}")

status_map = {
    'SUCCESS': 'COMPLETE',
    'FAILED': 'NOT_STARTED',
    'PARTIAL': 'PARTIALLY_COMPLETE'
}

# For each request, find closest dw_acc event matching reported_status
matched_events = set()
req_to_acc = {}

# Non-deletion cases
non_del_cases = [f'case_{i}' for i in range(533, 543)]

for _, r in all_req.iterrows():
    cid = r['case_id']
    if cid in non_del_cases:
        continue
    rep_at = pd.to_datetime(r['reported_at'])
    rep_stat = r['reported_status']
    
    # filter unallocated dw_acc events
    unalloc = dw_acc[~dw_acc['activity_id'].isin(matched_events)].copy()
    unalloc['diff'] = (unalloc['dt'] - rep_at).abs()
    
    # match status
    unalloc['mapped_stat'] = unalloc['reported_result'].map(status_map)
    cand = unalloc[unalloc['mapped_stat'] == rep_stat].sort_values('diff')
    if len(cand) > 0 and cand.iloc[0]['diff'] <= pd.Timedelta(hours=4):
        best = cand.iloc[0]
        matched_events.add(best['activity_id'])
        req_to_acc[cid] = best['resource_id']
    else:
        # fallback to any closest
        closest = unalloc.sort_values('diff')
        if len(closest) > 0 and closest.iloc[0]['diff'] <= pd.Timedelta(hours=4):
            best = closest.iloc[0]
            matched_events.add(best['activity_id'])
            req_to_acc[cid] = best['resource_id']

print(f"Total deletion requests: {len(all_req) - len(non_del_cases)}")
print(f"Matched to account: {len(req_to_acc)}")
