import os, glob

target_accounts = ['account_3960', 'account_9797', 'account_4745', 'account_994', 'account_4092', 'account_5521', 'account_9102']

def search_text(path, text):
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            for lno, line in enumerate(f, 1):
                for acc in target_accounts:
                    if acc in line:
                        print(f"[{acc}] Found in {path}:{lno} -> {line.strip()[:150]}")
    except Exception as e:
        pass

for root, dirs, files in os.walk('dataset'):
    for file in files:
        if file.endswith(('csv', 'txt', 'log', 'json', 'sql', 'md')):
            search_text(os.path.join(root, file), target_accounts)
