import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# For all 32 sample cases, let's see where the account_id appears in evidence or activity!
for _, row in sample_out.iterrows():
    cid = row['case_id']
    steps = json.loads(row['steps_json'])
    acc_ids = list(set(s['resource_id'] for s in steps if s['system_id'] == 'account_service'))
    ev_ids = list(set(s['evidence_id'] for s in steps if s['evidence_id']))
    print(f"--- {cid}: acc={acc_ids}, ev={ev_ids} ---")
    for acc in acc_ids:
        # Check system_activity
        act_rows = activity[activity['resource_id'] == acc]
        for _, ar in act_rows.iterrows():
            print(f"  act: {ar['activity_id']} {ar['event_type']} src={ar['source_system']} tgt={ar['target_system']} {ar['details']}")
