import pandas as pd, json

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
ef = pd.read_csv('dataset/evidence_files.csv')
ef_map = dict(zip(ef['file_id'], ef['captured_at']))

violations = []
for _, req in sample_req.iterrows():
    cid = req['case_id']
    aud_at = pd.to_datetime(req['audit_at'])
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    for s in steps:
        eid = s.get('evidence_id')
        if eid:
            cap_at_str = ef_map.get(eid)
            if cap_at_str:
                cap_at = pd.to_datetime(cap_at_str)
                if cap_at > aud_at:
                    violations.append((cid, eid, cap_at_str, req['audit_at']))
                else:
                    # Valid
                    pass

print(f"Total cited evidence items checked. Violations (cap_at > audit_at): {len(violations)}")
for v in violations:
    print(v)
