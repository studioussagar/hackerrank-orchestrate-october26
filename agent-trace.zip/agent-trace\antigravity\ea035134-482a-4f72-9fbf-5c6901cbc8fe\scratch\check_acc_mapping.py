import pandas as pd
import json

sample_req = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Let's see: how many deletion_worker -> account_service events are in system_activity.csv?
dw_acc = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()
dw_acc['dt'] = pd.to_datetime(dw_acc['event_time'])
print(f"Total deletion_worker -> account_service events: {len(dw_acc)}")

# Now for each sample case, let's find the matching account from sample_out
for _, r in sample_req.iterrows():
    cid = r['case_id']
    rep_at = pd.to_datetime(r['reported_at'])
    rep_stat = r['reported_status']
    
    out_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    acc_steps = [s for s in steps if s['system_id'] == 'account_service']
    expected_acc = acc_steps[0]['resource_id'] if acc_steps else None
    
    # Check dw_acc near reported_at
    dw_acc['diff'] = (dw_acc['dt'] - rep_at).abs()
    cands = dw_acc[dw_acc['diff'] <= pd.Timedelta(hours=3)].copy()
    cands_res = cands['resource_id'].tolist()
    print(f"{cid} (rep_at={r['reported_at']}, stat={rep_stat}): expected={expected_acc}, in_cands={expected_acc in cands_res}")
